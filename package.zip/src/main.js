const karyawanData = [
  { nama: "AGUNG KUSMAWAN", noInduk: "0026022CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "INDRA WAHYUDIN", noInduk: "0026025CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "TAUFIK ROCHMAT HIDAYAT", noInduk: "0026028CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "AHMAD NIKI RAMJANI", noInduk: "0226014CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "ISMAIL NURSALIM", noInduk: "0226016CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "SUMARJAYA EKAPUTRA", noInduk: "7326003CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "ALKAHFI RAMDANI", noInduk: "0426016CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "WAHYUDIN", noInduk: "7226005CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "HERIYANTO", noInduk: "7326002CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "SUDRAJAT", noInduk: "7326004CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DIDIN DJAENUDIN", noInduk: "7526002CMI", jabatan: "KOORDINATOR ULP", penempatan: "PADALARANG" },
  { nama: "EKO PRAYITNO", noInduk: "7726001CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "WALUYO", noInduk: "7726004CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "A. SUHENDI", noInduk: "7826002CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "ACENG KUSMANA", noInduk: "8026003CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DANI LUKMANSYAH", noInduk: "8026005CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "SOLIHIN MUSTOPA", noInduk: "8026007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "JAMALUDIN", noInduk: "8126003CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "AHMAD TAUFIK HIDAYAT", noInduk: "8126004CMI", jabatan: "PETUGAS ADMINISTRASI TEKNIK", penempatan: "PADALARANG" },
  { nama: "TOPIK ISMAIL NURMAWAN", noInduk: "8126009CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "USAM HENDI SURYAMAN", noInduk: "8126010CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "AMAS SURYANA", noInduk: "8226006CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "BUDIYANA", noInduk: "8226007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "SAMSU SUJANA", noInduk: "8226011CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "TATANG SUSANTO", noInduk: "8226012CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "TEDY GUNAWAN", noInduk: "8226013CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "KARFI AZHARI AKBAR", noInduk: "0026026CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "IMAM SOLIHIN", noInduk: "8426004CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "JOHAN", noInduk: "8426005CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "TONI SUGIANTO A", noInduk: "8426007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "AHMAD HIDAYAT MUSLIHUDIN", noInduk: "8526005CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "AGUS SUMARNA", noInduk: "8626001CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DARTA", noInduk: "8626006CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DANI HAMDANI", noInduk: "8726006CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "JUJUN DARMAWAN", noInduk: "8726010CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "ADE SUNARYA", noInduk: "8826001CMI", jabatan: "K3L", penempatan: "PADALARANG" },
  { nama: "RIKI KURNIAWAN", noInduk: "9026011CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DEDEN ABDULAH", noInduk: "9126005CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "HIBATUL WAFI FITRIYANTO", noInduk: "9126006CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "HADI CAHYA NUGRAHA", noInduk: "9126007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "RENDI RUDIANSYAH", noInduk: "9126011CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "SOPYAN ROMADON", noInduk: "9226007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "RONI HIDAYATULOH", noInduk: "9326007CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "DADI GUNTARA", noInduk: "9426010CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "NIA KURNIAWAN", noInduk: "9826014CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "FARIZ FAUZI", noInduk: "9926021CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "HARI MAHPRIANTO", noInduk: "9026008CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "NENDI SOLEHUDIN", noInduk: "9026010CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "MOCH ABYSAKTI ARSYIDIVA", noInduk: "0126021CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "HILMA SUKMANA JUPAL HERDIANA", noInduk: "8326006CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" },
  { nama: "WAWAN HERMAWAN", noInduk: "8026009CMI", jabatan: "PETUGAS PELAYANAN TEKNIK", penempatan: "PADALARANG" }
];

// State and Navigation
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  initForm();
  initSettings();
  loadDashboard();
});

function initNavigation() {
  const navItems = document.querySelectorAll('.nav-item');
  const views = document.querySelectorAll('.view');

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      
      navItems.forEach(n => n.classList.remove('active'));
      item.classList.add('active');

      const targetId = item.getAttribute('data-target');
      views.forEach(v => {
        v.classList.remove('active');
        if(v.id === targetId) {
          v.classList.add('active');
        }
      });

      if(targetId === 'view-dashboard') {
        loadDashboard();
      }
    });
  });
}

function initSettings() {
  const scriptUrlInput = document.getElementById('scriptUrl');
  const btnSaveUrl = document.getElementById('btn-save-url');
  const btnClearData = document.getElementById('btn-clear-data');
  const urlStatus = document.getElementById('url-status');

  const existingUrl = localStorage.getItem('spkl_script_url');
  if (existingUrl) {
    scriptUrlInput.value = existingUrl;
  }

  btnSaveUrl.addEventListener('click', () => {
    const url = scriptUrlInput.value.trim();
    if (url) {
      localStorage.setItem('spkl_script_url', url);
      urlStatus.classList.remove('hidden');
      setTimeout(() => urlStatus.classList.add('hidden'), 3000);
      showToast('URL Google Script berhasil disimpan!');
    } else {
      showToast('URL tidak boleh kosong', true);
    }
  });

  if (btnClearData) {
    btnClearData.addEventListener('click', () => {
      if (confirm('Yakin ingin mengosongkan semua data di dashboard?')) {
        localStorage.removeItem('spkl_history');
        // Reload the page so dashboard starts empty
        location.reload();
      }
    });
  }
}

function initForm() {
  const form = document.getElementById('spkl-form');
  const namaSelect = document.getElementById('nama');
  const noIndukInput = document.getElementById('noInduk');
  const jabatanInput = document.getElementById('jabatan');
  const penempatanInput = document.getElementById('penempatan');
  
  const btnSubmit = document.getElementById('btn-submit');
  const spinner = document.querySelector('.spinner');
  const btnText = btnSubmit.querySelector('span');
  
  const waktuLemburInput = document.getElementById('waktuLembur');
  const jmlJamHidden = document.getElementById('jmlJam');
  const fileInput = document.getElementById('fotoEviden');
  let base64Photo = '';
  let photoMimeType = '';

  const waktuMulaiInput = document.getElementById('waktuMulai');
  const waktuSelesaiInput = document.getElementById('waktuSelesai');
  const totalJamSpan = document.getElementById('totalJamLembur');

  function calculateLembur() {
    if (waktuMulaiInput.value && waktuSelesaiInput.value) {
      let [h1, m1] = waktuMulaiInput.value.split(':').map(Number);
      let [h2, m2] = waktuSelesaiInput.value.split(':').map(Number);
      
      let totalMinutes = (h2 * 60 + m2) - (h1 * 60 + m1);
      if (totalMinutes < 0) {
        totalMinutes += 24 * 60;
      }
      
      let totalHours = totalMinutes / 60;
      totalHours = Math.round(totalHours * 100) / 100;
      
      totalJamSpan.textContent = totalHours;
      if (waktuLemburInput) waktuLemburInput.value = `${waktuMulaiInput.value} - ${waktuSelesaiInput.value}`;
      if (jmlJamHidden) jmlJamHidden.value = totalHours;
    } else {
      totalJamSpan.textContent = '0';
      if (waktuLemburInput) waktuLemburInput.value = '';
      if (jmlJamHidden) jmlJamHidden.value = '';
    }
  }

  if (waktuMulaiInput && waktuSelesaiInput) {
    ['input', 'change'].forEach(evt => {
      waktuMulaiInput.addEventListener(evt, calculateLembur);
      waktuSelesaiInput.addEventListener(evt, calculateLembur);
    });
  }

  // Detect Week of Month
  const tglLemburInput = document.getElementById('tglLembur');
  const mingguKeInput = document.getElementById('mingguKe');
  if (tglLemburInput && mingguKeInput) {
    tglLemburInput.addEventListener('change', () => {
      if (tglLemburInput.value) {
        const date = new Date(tglLemburInput.value);
        // 0 = Sunday, 1 = Monday, dst.
        const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1).getDay(); 
        // Hitung minggu ke berapa berdasarkan posisi di kalender
        const weekOfMonth = Math.ceil((date.getDate() + firstDayOfMonth) / 7);
        mingguKeInput.value = "Minggu ke-" + weekOfMonth;
      } else {
        mingguKeInput.value = "";
      }
    });
  }

  // Populate Nama Select
  karyawanData.forEach(k => {
    const opt = document.createElement('option');
    opt.value = k.nama;
    opt.textContent = k.nama;
    namaSelect.appendChild(opt);
  });

  // Autofill Logic
  namaSelect.addEventListener('change', (e) => {
    const selectedName = e.target.value;
    const k = karyawanData.find(x => x.nama === selectedName);
    if(k) {
      noIndukInput.value = k.noInduk;
      jabatanInput.value = k.jabatan;
      penempatanInput.value = k.penempatan;
    }
  });

  // Coba autofill berdasarkan user login
  try {
    const auth = sessionStorage.getItem('spkl_auth');
    if (auth) {
      const data = JSON.parse(auth);
      const userDisplay = (data.displayName || '').toLowerCase();
      const userName = (data.username || '').toLowerCase();
      
      const match = karyawanData.find(x => x.nama.toLowerCase() === userDisplay || x.nama.toLowerCase() === userName);
      if (match) {
        namaSelect.value = match.nama;
        namaSelect.dispatchEvent(new Event('change'));
      }
    }
  } catch (err) {
    console.error('Gagal autofill nama:', err);
  }

  // Fungsi untuk update dropdown karyawan dari Google Sheet
  async function fetchKaryawanData() {
    const scriptUrl = localStorage.getItem('spkl_script_url');
    if (!scriptUrl) return;

    try {
      // Tambahkan ?action=getPetugas kalau butuh, secara default doGet akan mengembalikan data petugas
      const response = await fetch(scriptUrl + "?action=getPetugas");
      const result = await response.json();
      
      if (result.status === "success" && Array.isArray(result.data)) {
        karyawanData.length = 0; // Kosongkan array lama
        karyawanData.push(...result.data); // Isi dengan data dari Google Sheet
        
        // Render ulang options
        namaSelect.innerHTML = '<option value="" disabled selected>Pilih Nama Karyawan...</option>';
        karyawanData.forEach(k => {
          const opt = document.createElement('option');
          opt.value = k.nama;
          opt.textContent = k.nama;
          namaSelect.appendChild(opt);
        });

        // Coba autofill ulang dengan data baru
        const auth = sessionStorage.getItem('spkl_auth');
        if (auth) {
          const data = JSON.parse(auth);
          const userDisplay = (data.displayName || '').toLowerCase();
          const userName = (data.username || '').toLowerCase();
          const match = karyawanData.find(x => x.nama.toLowerCase() === userDisplay || x.nama.toLowerCase() === userName);
          if (match) {
            namaSelect.value = match.nama;
            namaSelect.dispatchEvent(new Event('change'));
          }
        }
      }
    } catch (error) {
      console.error("Gagal mengambil data petugas dari Google Sheet:", error);
    }
  }

  // Ambil data petugas di background
  fetchKaryawanData();

  // File Upload Logic
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(event) {
        const fullBase64 = event.target.result;
        // Split data:image/jpeg;base64,...
        const parts = fullBase64.split(';');
        photoMimeType = parts[0].split(':')[1];
        base64Photo = parts[1].split(',')[1];
      };
      reader.readAsDataURL(file);
    } else {
      base64Photo = '';
      photoMimeType = '';
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const scriptUrl = localStorage.getItem('spkl_script_url');
    if (!scriptUrl) {
      showToast('Harap atur URL Google Script di Pengaturan terlebih dahulu!', true);
      document.querySelector('[data-target="view-settings"]').click();
      return;
    }

    // Paksa hitung ulang sebelum submit
    if (typeof calculateLembur === 'function') {
      calculateLembur();
    }

    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Validasi: pastikan waktu lembur sudah diisi
    if (!data.waktuMulai || !data.waktuSelesai) {
      showToast('Harap isi Waktu Mulai dan Waktu Selesai lembur!', true);
      btnText.classList.remove('hidden');
      spinner.classList.add('hidden');
      btnSubmit.disabled = false;
      return;
    }
    if (!data.jmlJam || parseFloat(data.jmlJam) <= 0) {
      showToast('Waktu selesai harus lebih dari waktu mulai!', true);
      btnText.classList.remove('hidden');
      spinner.classList.add('hidden');
      btnSubmit.disabled = false;
      return;
    }

    // jmlJam already synced via hidden field; ensure consistency
    data.jmlJam = data.jmlJam;

    // Map 'keterangan' → 'keteranganTambahan' as expected by the Apps Script
    data.keteranganTambahan = data.keterangan;

    // Inject photo data
    data.fotoBase64 = base64Photo;
    data.fotoMimeType = photoMimeType;
    data.fotoFileName = data.nama.replace(/\s+/g, '_') + '_Eviden.jpg';
    
    btnText.classList.add('hidden');
    spinner.classList.remove('hidden');
    btnSubmit.disabled = true;

    try {
      const response = await fetch(scriptUrl, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Content-Type': 'text/plain;charset=utf-8',
        }
      });

      saveToHistory(data);
      
      showToast('SPKL Berhasil Disimpan!');
      form.reset();
      // reset specific fields
      base64Photo = '';
      photoMimeType = '';
      
      document.querySelector('[data-target="view-dashboard"]').click();
      
    } catch (error) {
      console.error('Error:', error);
      const msg = error.message || 'Koneksi gagal';
      showToast('Gagal: ' + msg.substring(0, 80), true);
      saveToHistory(data);
      form.reset();
    } finally {
      btnText.classList.remove('hidden');
      spinner.classList.add('hidden');
      btnSubmit.disabled = false;
    }
  });

  // Reset tampilan jumlah jam saat form direset
  form.addEventListener('reset', () => {
    setTimeout(() => {
      const span = document.getElementById('totalJamLembur');
      if (span) span.textContent = '0';
    }, 0);
  });
}

function saveToHistory(data) {
  let history = JSON.parse(localStorage.getItem('spkl_history') || '[]');
  data.timestamp = new Date().getTime();
  history.unshift(data);
  if(history.length > 50) history.pop();
  localStorage.setItem('spkl_history', JSON.stringify(history));
}

function loadDashboard() {
  const history = JSON.parse(localStorage.getItem('spkl_history') || '[]');
  const entriesContainer = document.getElementById('recent-entries');
  const totalLemburEl = document.getElementById('summary-total');
  const totalEntriesEl = document.getElementById('summary-entries');

  document.getElementById('btn-refresh').addEventListener('click', loadDashboard);

  if (history.length === 0) {
    entriesContainer.innerHTML = '<div class="empty-state">Belum ada data lembur tersimpan di perangkat ini.</div>';
    totalLemburEl.textContent = '0 Jam';
    totalEntriesEl.textContent = '0';
    return;
  }

  let totalJam = 0;
  let html = '';
  const currentMonth = new Date().getMonth();
  let monthEntries = 0;

  history.forEach(entry => {
    const entryDate = new Date(entry.tglLembur);
    if(entryDate.getMonth() === currentMonth) {
      monthEntries++;
      totalJam += parseFloat(entry.jmlJam || entry.waktuLembur || 0);
    }

    const dateStr = entryDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
    
    html += `
      <div class="entry-item">
        <div class="entry-header">
          <span class="entry-name">${entry.nama} - ${entry.noInduk}</span>
          <span class="entry-badge">${entry.kategori}</span>
        </div>
        <div class="entry-details">
          <span>${entry.keteranganLembur}</span>
        </div>
        <div class="entry-details" style="margin-top: 6px; color: #64748b;">
          <span>${dateStr} (${entry.shift})</span>
          <span><strong>${entry.jmlJam || entry.waktuLembur} Jam</strong> ${entry.jmlJam ? `(${entry.waktuLembur})` : ''}</span>
        </div>
      </div>
    `;
  });

  entriesContainer.innerHTML = html;
  totalLemburEl.textContent = `${totalJam} Jam`;
  totalEntriesEl.textContent = monthEntries;
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  const msgEl = document.getElementById('toast-message');
  msgEl.textContent = message;
  
  if (isError) toast.classList.add('error');
  else toast.classList.remove('error');
  
  toast.classList.remove('hidden');
  void toast.offsetWidth;
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.classList.add('hidden'), 300);
  }, 3000);
}
